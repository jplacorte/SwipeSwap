import React from 'react';
import { MDBCol, MDBRow, MDBView, MDBCarousel, MDBCarouselInner, MDBCarouselItem, MDBContainer, MDBBtn, MDBMask, MDBIcon, MDBCard, MDBCardBody, MDBCardImage, MDBCardTitle, MDBCardText, MDBCardFooter } from "mdbreact";
import NavbarLanding from './navbar';
import LandingNavbar from './navbar';
import LandingCarousel from './carousel';
import "../../css/style.css";
import "../../css/mediaQuery.css";
import Slide1 from '../../assets/images/bg4.jpg';
import Slide2 from '../../assets/images/bg2.jpg';
import Slide3 from '../../assets/images/bg5.jpg';
import Slide4 from '../../assets/images/bg6.jpg';
import MSlide1 from '../../assets/images/slide1.png';
import MSlide2 from '../../assets/images/slide2.png';
import MSlide3 from '../../assets/images/slide3.png';
import Items1 from "../../assets/images/bg8.jpg";
import Items2 from "../../assets/images/bg7.jpg";
import Items3 from "../../assets/images/bg9.jpg";
import Items4 from "../../assets/images/bg10.jpg";
import Footer from "../../assets/images/bg1.jpg";


function LandingPage() {
    return (
        <div>
            <LandingNavbar/>
            <div className="mb-5" id="home"><LandingCarousel/></div>
            
            {/* SECTION 1 */}
            <div className="section-1 mb-5" id="about">
                <MDBRow className="mx-auto text-center">
                    <MDBCol className="p-0" size="12">
                        <div className="landing-title px-2">
                            Some text here
                            <div className="landing-title-desc px-2">Some text here</div>
                        </div>
                    </MDBCol>
                    <MDBCol size="12" className="landing-desc p-0 text-center mt-2 mb-3">
                        Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here
                    </MDBCol>
                    <MDBCol className="p-0" size="12">
                    <MDBCarousel
                        activeItem={1}
                        length={3}
                        showControls={false}
                        showIndicators={true}
                        interval={5000}
                        className="z-depth-1 section-1-carousel mb-3"
                        slide
                    >
                    <MDBCarouselInner className="section-1-carousel-inner">
                        <MDBCarouselItem itemId="1">
                        <MDBView>
                           <img
                             className="w-100"
                             src={Slide1}
                             alt="First slide"
                           />
                         </MDBView>
                       </MDBCarouselItem>
                       <MDBCarouselItem itemId="2">
                        <MDBView>
                           <img
                             className="w-100"
                             src={Slide2}
                             alt="Second slide"
                           />
                         </MDBView>
                       </MDBCarouselItem>
                       <MDBCarouselItem itemId="3">
                        <MDBView>
                           <img
                             className="w-100"
                             src={Slide3}
                             alt="Third slide"
                           />
                         </MDBView>
                       </MDBCarouselItem>
                    </MDBCarouselInner>
                  </MDBCarousel>
              </MDBCol>
              <MDBCol className="p-0 text-left" md="4">
                <div className="section-1-title">Sample text</div>
                <div className="section-1-desc">Sample text Sample text Sample text Sample text Sample text Sample text Sample text Sample text Sample text Sample text Sample text Sample text Sample text Sample text</div>
              </MDBCol>
              <MDBCol className="p-0 text-left" md="4">
                <div className="section-1-title">Sample text</div>
                <div className="section-1-desc">Sample text Sample text Sample text Sample text Sample text Sample text Sample text Sample text Sample text Sample text Sample text Sample text Sample text Sample text</div>
              </MDBCol>
              <MDBCol className="p-0 text-left" md="4">
                <div className="section-1-title">Sample text</div>
                <div className="section-1-desc">Sample text Sample text Sample text Sample text Sample text Sample text Sample text Sample text Sample text Sample text Sample text Sample text Sample text Sample text</div>
              </MDBCol>
              <MDBCol className="section-1-btn-container p-0 mt-4" size="12">
                <MDBBtn className="section-1-btn w-100 m-0">REGISTER NOW USING FACEBOOK</MDBBtn>
              </MDBCol>
            </MDBRow>
            </div>

            {/* SECTION 2 */}
            <div className="section-2 mb-5">
             <MDBRow className="mx-auto">
               <MDBCol className="p-0" size="12">
                <MDBView>
                  <img
                  src={Slide4}
                  className="img-fluid"
                  alt=""
                />
                <MDBMask className="flex-center" overlay="black-strong">
                <div className="device">
	                <div className="device-content">				
                    <MDBCarousel 
                        className="mobile-slider"
                        activeItem={1}
                        length={3}
                        showControls={false}
                        showIndicators={false}
                        interval={4000}
                        className="z-depth-1"
                        slide
                    >
                    <MDBCarouselInner className="section-2-carousel-inner">
                    <MDBCarouselItem itemId="1">
                        <MDBView>
                           <img
                             className=""
                             src={MSlide1}
                             alt="First slide"
                           />
                         </MDBView>
                       </MDBCarouselItem>
                       <MDBCarouselItem itemId="2">
                        <MDBView>
                           <img
                             className=""
                             src={MSlide2}
                             alt="Third slide"
                           />
                         </MDBView>
                       </MDBCarouselItem>
                       <MDBCarouselItem itemId="3">
                        <MDBView>
                           <img
                             className=""
                             src={MSlide3}
                             alt="Fourth slide"
                           />
                         </MDBView>
                       </MDBCarouselItem> 
                    </MDBCarouselInner>
                    </MDBCarousel>
                </div>
               </div>
                </MDBMask>
                </MDBView>
               </MDBCol>
             </MDBRow>
            </div>

            {/* SECTION 3 */}
            <div className="section-3 mb-5" id="features">
              <MDBRow className="mx-auto text-center">
                <MDBCol className="p-0" size="12">
                  <div className="landing-title px-2">
                      Some text here
                      <div className="landing-title-desc px-2">Some text here</div>
                  </div>
                </MDBCol>
                <MDBCol size="12" className="landing-desc p-0 text-center mt-2 mb-4">
                    Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here
                </MDBCol>
                <MDBCol className="section-3-item p-3 my-3" md="4">
                  <MDBIcon className="mb-3" icon="sync" />
                  <div className="section-3-title mb-2">Sample Text</div>
                  <div className="section-3-desc">Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here</div>
                </MDBCol>
                <MDBCol className="section-3-item p-3 my-3" md="4">
                  <MDBIcon className="mb-3" icon="database" />
                  <div className="section-3-title mb-2">Sample Text</div>
                  <div className="section-3-desc">Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here</div>
                </MDBCol>
                <MDBCol className="section-3-item p-3 my-3" md="4">
                  <MDBIcon className="mb-3" icon="bell" />
                  <div className="section-3-title mb-2">Sample Text</div>
                  <div className="section-3-desc">Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here</div>
                </MDBCol>
                <MDBCol className="section-3-item p-3 my-3" md="4">
                  <MDBIcon className="mb-3" icon="comment" />
                  <div className="section-3-title mb-2">Sample Text</div>
                  <div className="section-3-desc">Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here</div>
                </MDBCol>
                <MDBCol className="section-3-item p-3 my-3" md="4">
                  <MDBIcon className="mb-3" icon="users" />
                  <div className="section-3-title mb-2">Sample Text</div>
                  <div className="section-3-desc">Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here</div>
                </MDBCol>
                <MDBCol className="section-3-item p-3 my-3" md="4">
                  <MDBIcon className="mb-3" icon="tools" />
                  <div className="section-3-title mb-2">Sample Text</div>
                  <div className="section-3-desc">Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here</div>
                </MDBCol>
              </MDBRow>
              </div>

              {/* SECTION 4 */}
              <div className="section-4 mb-5">
                <MDBCarousel
                  activeItem={1}
                  length={4}
                  showControls={false}
                  showIndicators={false}
                  interval={3000}
                  className="z-depth-1 section-4-carousel"
                >
                <MDBCarouselInner className="section-4-carousel-inner">
                  <MDBCarouselItem itemId="1">
                    <MDBView>
                      <img
                        className=""
                        src={Items1}
                        alt="First slide"
                      />
                    <MDBMask className="flex-center text-center" overlay="black-strong">
                      <p className="section-4-desc">Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here</p>
                    </MDBMask>
                    </MDBView>
                  </MDBCarouselItem>
                  <MDBCarouselItem itemId="2">
                    <MDBView>
                      <img
                        className=""
                        src={Items2}
                        alt="Second slide"
                      />
                    <MDBMask className="flex-center text-center" overlay="black-strong">
                      <p className="section-4-desc">Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here</p>
                    </MDBMask>
                    </MDBView>
                  </MDBCarouselItem>
                  <MDBCarouselItem itemId="3">
                    <MDBView>
                      <img
                        className=""
                        src={Items3}
                        alt="Third slide"
                      />
                    <MDBMask className="flex-center text-center" overlay="black-strong">
                      <p className="section-4-desc">Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here</p>
                    </MDBMask>
                    </MDBView>
                  </MDBCarouselItem>
                  <MDBCarouselItem itemId="4">
                    <MDBView>
                      <img
                        className=""
                        src={Items4}
                        alt="Fourth slide"
                      />
                    <MDBMask className="flex-center text-center" overlay="black-strong">
                      <p className="section-4-desc">Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here</p>
                    </MDBMask>
                    </MDBView>
                  </MDBCarouselItem>
                </MDBCarouselInner>
              </MDBCarousel>
              </div>

              {/* SECTION 5 */}
              <div className="section-5" id="reviews">
                <MDBRow className="mx-auto text-center">
                  <MDBCol className="p-0" size="12">
                    <div className="landing-title px-2">
                        Some text here
                        <div className="landing-title-desc px-2">Some text  here</div>
                    </div>
                  </MDBCol>
                  <MDBCol size="12" className="landing-desc p-0 text-center mt-2 mb-4">
                    Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here Some text here
                  </MDBCol>

                  <MDBCol className="mb-4" lg="3">
                  <MDBCard className="section-5-card">
                    <MDBCardImage className="img-fluid" src="https://mdbootstrap.com/img/Photos/Avatars/img%20%2810%29.jpg" waves />
                    <MDBCardBody className="text-center" style={{marginTop: "-2%"}}>
                      <MDBCardTitle>
                        <div className="section-5-card-title">Card title</div>
                        <div className="my-2" style={{fontSize: '14px', fontStyle: 'italic'}}>Sample Text</div>     
                      </MDBCardTitle>
                      <MDBCardText>
                        Some quick example text to build on the card title and make
                        up the bulk of the card&apos;s content.
                      </MDBCardText>
                    </MDBCardBody>
                  </MDBCard>
                  </MDBCol>
                  <MDBCol className="mb-4" lg="3">
                  <MDBCard className="section-5-card">
                    <MDBCardImage className="img-fluid" src="https://mdbootstrap.com/img/Photos/Avatars/img%20(20).jpg" waves />
                    <MDBCardBody className="text-center" style={{marginTop: "-2%"}}>
                      <MDBCardTitle>
                        <div className="section-5-card-title">Card title</div>
                        <div className="my-2" style={{fontSize: '14px', fontStyle: 'italic'}}>Sample Text</div>     
                      </MDBCardTitle>
                      <MDBCardText>
                        Some quick example text to build on the card title and make
                        up the bulk of the card&apos;s content.
                      </MDBCardText>
                    </MDBCardBody>
                  </MDBCard>
                  </MDBCol>
                  <MDBCol className="mb-4" lg="3">
                  <MDBCard className="section-5-card">
                    <MDBCardImage className="img-fluid" src="https://mdbootstrap.com/img/Photos/Others/men.jpg" waves />
                    <MDBCardBody className="text-center" style={{marginTop: "-2%"}}>
                      <MDBCardTitle>
                        <div className="section-5-card-title">Card title</div>
                        <div className="my-2" style={{fontSize: '14px', fontStyle: 'italic'}}>Sample Text</div>     
                      </MDBCardTitle>
                      <MDBCardText>
                        Some quick example text to build on the card title and make
                        up the bulk of the card&apos;s content.
                      </MDBCardText>
                    </MDBCardBody>
                  </MDBCard>
                  </MDBCol>
                  <MDBCol className="mb-4" lg="3">
                  <MDBCard className="section-5-card">
                    <MDBCardImage className="img-fluid" src="https://mdbootstrap.com/img/Photos/Horizontal/People/6-col/img%20%283%29.jpg" waves />
                    <MDBCardBody className="text-center" style={{marginTop: "-2%"}}>
                      <MDBCardTitle>
                        <div className="section-5-card-title">Card title</div>
                        <div className="my-2" style={{fontSize: '14px', fontStyle: 'italic'}}>Sample Text</div>     
                      </MDBCardTitle>
                      <MDBCardText>
                        Some quick example text to build on the card title and make
                        up the bulk of the card&apos;s content.
                      </MDBCardText>
                    </MDBCardBody>
                  </MDBCard>
                  </MDBCol>
                </MDBRow>
              </div>

              {/* FOOTER */}
              <div className="ss-footer mx-auto" id="contact">
                  <MDBView className="mx-auto">
                    <img
                      className="w-100"
                      src={Footer}
                    />
                <MDBMask className="ss-footer-mask" overlay="black-strong">
                  <div className="ss-footer-title text-center p-2">STAY CONNECTED!</div>
                  <div className="ss-footer-desc flex-center">
                  <div className="d-flex bd-highlight example-parent mx-auto">

                  <div className="flex-fill bd-highlight col-example footer-icon-container mx-3">  
                    <div className="footer-icon">
                      <MDBIcon className="flex-center" fab icon="twitter" />
                    </div> 
                  </div>

                  <div className="flex-fill bd-highlight col-example footer-icon-container mx-3">  
                    <div className="footer-icon">
                      <MDBIcon className="flex-center" fab icon="instagram" />
                    </div> 
                  </div>

                  <div className="flex-fill bd-highlight col-example footer-icon-container mx-3">  
                    <div className="footer-icon">
                      <MDBIcon className="flex-center" fab icon="facebook-f" />
                    </div> 
                  </div>

                  <div className="flex-fill bd-highlight col-example footer-icon-container mx-3">  
                    <div className="footer-icon">
                      <MDBIcon className="flex-center" fab icon="google-plus-g" />
                    </div> 
                  </div>
                  </div>
                  </div>
              
                  </MDBMask>
              </MDBView>
                <div className="footer-copyright text-center py-3 black white-text">
                  <MDBContainer fluid>
                    &copy; {new Date().getFullYear()} Copyright: <a href="https://www.mdbootstrap.com" style={{color: "#167D7F"}}> SwipeSwap.me </a>
                  </MDBContainer>
                </div>
              </div>

        </div>
    )
}

export default LandingPage;
